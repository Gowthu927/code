export const AddDataAction = data => {
  return {
    type: "USER_INPUT_DATA",
    data: data
  };
};
